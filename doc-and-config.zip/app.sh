#!/bin/bash
JAR_NAME=bcsr-dataload-0.0.1-SNAPSHOT
Suffix=jar
APP_NAME=$JAR_NAME.$Suffix
CUR_SHELL_DIR=`pwd`
JAR_PATH=$CUR_SHELL_DIR/$APP_NAME
#配置文件路径
CONFIG_PATH="--Dspring.config.location=config/"
LOG_PATH=$CUR_SHELL_DIR/logs/$JAR_NAME.log
SPRING_PROFILES_ACTIV="--spring.profiles.active=dev"
JAVA_MEM_OPTS=" -server -Xms2048m -Xmx2048m -XX:PermSize=256m -XX:MaxPermSize=512m"
#JAVA_MEM_OPTS=""
#使用说明，用来提示输入参数
usage() {
 echo "Usage: sh 脚本名.sh [start|stop|restart|status|monitor]"
 exit 1
}

#检查程序是否在运行
is_exist(){
 pid=`ps -ef|grep $APP_NAME|grep -v grep|awk '{print $2}' `
 #如果不存在返回1，存在返回0
 if [ -z "${pid}" ]; then
 return 1
 else
 return 0
 fi
}

#启动方法
start(){
 is_exist
 if [ $? -eq "0" ]; then
 echo "${APP_NAME} is already running. pid=${pid} ."
 else
 nohup java $JAVA_MEM_OPTS -jar $JAR_PATH $CONFIG_PATH $SPRING_PROFILES_ACTIV> $LOG_PATH 2>&1 &
 #nohup java $JAVA_MEM_OPTS -jar $JAR_PATH $CONFIG_PATH $SPRING_PROFILES_ACTIV> /dev/null 2>&1 &
 echo "${APP_NAME} start success"
 fi
}

#停止方法
stop(){
 is_exist
 if [ $? -eq "0" ]; then
 kill -9 $pid
 else
 echo "${APP_NAME} is not running"
 fi
}

#输出运行状态
status(){
 is_exist
 if [ $? -eq "0" ]; then
 echo "${APP_NAME} is running. Pid is ${pid}"
 else
 echo "${APP_NAME} is NOT running."
 fi
}

#检查状态,如果没有运行，那么执行启动脚本
monitor(){
 is_exist
 if [ $? -eq "0" ]; then
 echo "${APP_NAME} is running. Pid is ${pid}"
 else
 echo "${APP_NAME} is NOT running."
 start
 fi
}

#重启
restart(){
 stop
 start
}

#根据输入参数，选择执行对应方法，不输入则执行使用说明
case "$1" in
 "start")
 start
 ;;
 "stop")
 stop
 ;;
 "status")
 status
 ;;
 "restart")
 restart
 ;;
 "monitor")
 monitor
 ;;
 *)
 usage
 ;;
esac